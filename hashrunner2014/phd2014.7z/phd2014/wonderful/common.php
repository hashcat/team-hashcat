<?PHP

$algos = array (
    0 => 'md2',
    1 => 'md4',
    2 => 'md5',
    3 => 'sha1',
    4 => 'sha224',
    5 => 'sha256',
    6 => 'sha384',
    7 => 'sha512',
);

$helpers = array(
    100 => 'base64_encode',
    101 => 'bin2hex',
    102 => 'strrev',
    103 => 'str_double',
);

#$local_salt = file_get_contents('salt.txt');
