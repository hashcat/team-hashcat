<?php

include 'common.php';
include 'funcs.php';
include 'db.inc';

$noHMAC = file ("HMAC_no", FILE_IGNORE_NEW_LINES);
$usercnt = count ($noHMAC);

$dict = fopen('php://stdin', 'r');


$count = 0;
$found = 0;
$starttime = microtime(true);

print "\n";

while (! feof ($dict))
{
        $plain = trim (fgets ($dict));

#       fwrite (STDERR, "$plain\n");

        foreach ($noHMAC as $user)
        {
                $row = $hashdb[$user];

                if (do_hash($plain, $row['salt'], $row['modes'], $user) === $row['hash'])
                {
                        $found++;

$fp = fopen("bla", "a");

fprintf ($fp, "%s:%s\n", $row['hash'], $plain);

fclose ($fp);
                        echo $user." ".$row['hash'].":".$plain."\n\n\n\n";
                }

                $count++;

                if ($count % 50000 == 0)
                        fprintf (STDERR, "%ld found   %ld p/s %ld c/s %ld attempts in %ld seconds\r", $found, ($count / (microtime(true) - $starttime)) / $usercnt, $count / (microtime(true) - $starttime), $count, microtime(true) - $starttime);
        }
}


/*
if (isset($_POST, $_POST['login'], $_POST['password']))
{
                if (array_key_exists($_POST['login'], $hashdb))
                {
                                $row = $hashdb[$_POST['login']];
                                if (do_hash($_POST['password'], $row['salt'], $row['modes']) === $row['hash'])
                                {
                                                header('Location: http://admin_tgsEFYZfpHcLXEWk.hashrunner.zone');
                                                exit();
                                }
                }
}
?><h1>It works!</h1>
*/
