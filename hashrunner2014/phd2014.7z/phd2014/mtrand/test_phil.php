<?php
$nl = "\n";

$srand = 0;
mt_srand ($srand);

echo mt_rand () . $nl;
echo mt_rand () . $nl;
echo mt_rand () . $nl;


?>
